package com.bootcamp26.webflux.apirest.app.handler;

import static org.springframework.web.reactive.function.BodyInserters.fromObject;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.bootcamp26.webflux.apirest.app.models.documents.Movement;
import com.bootcamp26.webflux.apirest.app.models.services.MovementService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class MovementHandler {

	@Autowired
	private MovementService service;
		
	@Autowired
	private Validator validator;
	

	public Mono<ServerResponse> listar(ServerRequest request){
		return ServerResponse.ok()
				.contentType(MediaType.APPLICATION_JSON_UTF8)
				.body(service.findAll(), Movement.class);
	}
	
	public Mono<ServerResponse> ver(ServerRequest request){
		
		String id = request.pathVariable("id");
		return service.findById(id).flatMap( p -> ServerResponse
				.ok()
				.contentType(MediaType.APPLICATION_JSON_UTF8)
				.body(fromObject(p)))
				.switchIfEmpty(ServerResponse.notFound().build());
	}
			
	public Mono<ServerResponse> crear(ServerRequest request){
		Mono<Movement> movement = request.bodyToMono(Movement.class);
		
		return movement.flatMap(p -> {
			
			Errors errors = new BeanPropertyBindingResult(p, Movement.class.getName());
			validator.validate(p, errors);
			
			if(errors.hasErrors()) {
				return Flux.fromIterable(errors.getFieldErrors())
						.map(fieldError -> "El campo " + fieldError.getField() + " " + fieldError.getDefaultMessage())
						.collectList()
						.flatMap(list -> ServerResponse.badRequest().body(fromObject(list)));
			} else {
				//if(p.getCreateAt() ==null) {
				//	p.setCreateAt(new Date());
				//}
				return service.save(p).flatMap(pdb -> ServerResponse
						.created(URI.create("/api/v2/movements/".concat(pdb.getId())))
						.contentType(MediaType.APPLICATION_JSON_UTF8)
						.body(fromObject(pdb)));
			}
			
		});
	}
	
	public Mono<ServerResponse> editar(ServerRequest request){
		Mono<Movement> movement = request.bodyToMono(Movement.class);
		String id = request.pathVariable("id");
		
		Mono<Movement> movementDb = service.findById(id);
		
		return movementDb.zipWith(movement, (db, req) -> {			
			db.setAmount(req.getAmount());
			db.setOperationType(req.getOperationType());
			db.setAccount(req.getAccount());
			db.setState(req.getState());
			
			return db;
		}).flatMap(p -> ServerResponse.created(URI.create("/api/v2/movements/".concat(p.getId())))
				.contentType(MediaType.APPLICATION_JSON_UTF8)
				.body(service.save(p), Movement.class))
		.switchIfEmpty(ServerResponse.notFound().build());
		
	}
	
	public Mono<ServerResponse> eliminar(ServerRequest request){
		String id = request.pathVariable("id");
		
		Mono<Movement> movementDb = service.findById(id);
		
		return movementDb.flatMap(p-> service.delete(p).then(ServerResponse.noContent().build()))
				.switchIfEmpty(ServerResponse.notFound().build());
		
	}
	
}
