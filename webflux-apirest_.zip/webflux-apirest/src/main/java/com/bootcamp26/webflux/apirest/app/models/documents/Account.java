package com.bootcamp26.webflux.apirest.app.models.documents;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Document(collection="accounts")
public class Account {

    @Id
    private String id;

    @NotEmpty
    private String accountType;

    @Valid
    @NotNull
    private Person person;

    @NotEmpty
    private String accountNumber;

    @NotEmpty
    private String cardNumber;

    //@DateTimeFormat(pattern = "yyyy-MM-dd")
    @NotEmpty
    private String dateExpires;

    @NotNull
    private Double lineAvailable;

    @NotNull
    private Double balanceAvailable;

    @NotNull
    private Integer state;

    public Account() {
    }

    public Account(String accountNumber, String cardNumber, String dateExpires, Double lineAvailable, Double balanceAvailable, Integer state) {
        this.accountNumber = accountNumber;
        this.cardNumber = cardNumber;
        this.dateExpires = dateExpires;
        this.lineAvailable = lineAvailable;
        this.balanceAvailable = balanceAvailable;
        this.state = state;
    }

    public Account(String accountType, Person person, String accountNumber, String cardNumber, String dateExpires, Double lineAvailable, Double balanceAvailable, Integer state) {

        this.accountType = accountType;
        this.person = person;
        this.accountNumber = accountNumber;
        this.cardNumber = cardNumber;
        this.dateExpires = dateExpires;
        this.lineAvailable = lineAvailable;
        this.balanceAvailable = balanceAvailable;
        this.state = state;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getDateExpires() {
        return dateExpires;
    }

    public void setDateExpires(String dateExpires) {
        this.dateExpires = dateExpires;
    }

    public Double getLineAvailable() {
        return lineAvailable;
    }

    public void setLineAvailable(Double lineAvailable) {
        this.lineAvailable = lineAvailable;
    }

    public Double getBalanceAvailable() {
        return balanceAvailable;
    }

    public void setBalanceAvailable(Double balanceAvailable) {
        this.balanceAvailable = balanceAvailable;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }
}
