package com.bootcamp26.webflux.apirest.app.models.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bootcamp26.webflux.apirest.app.models.dao.AccountDao;
import com.bootcamp26.webflux.apirest.app.models.dao.MovementDao;
import com.bootcamp26.webflux.apirest.app.models.documents.Account;
import com.bootcamp26.webflux.apirest.app.models.documents.Movement;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class MovementServiceImpl implements MovementService {

	   @Autowired
	    private MovementDao dao;

	    @Autowired
	    private AccountDao accountDao;

	    @Override
	    public Flux<Movement> findAll() {
	        return dao.findAll();
	    }

	    @Override
	    public Mono<Movement> findById(String id) {
	        return dao.findById(id);
	    }

	    @Override
	    public Mono<Movement> save(Movement movement) {
	        return dao.save(movement);
	    }

	    @Override
	    public Mono<Void> delete(Movement movement) {
	        return dao.delete(movement);
	    }
	    
/*
	    @Override
	    public Mono<Account> findByAccountNumber(String accountNumber) {
	        return dao.findByAccountNumber(accountNumber);
	    }*/

	    @Override
	    public Flux<Account> findAllAccount() {
	        return accountDao.findAll();
	    }

	    @Override
	    public Mono<Account> findAccountById(String id) {
	        return accountDao.findById(id);
	    }

	    @Override
	    public Mono<Account> saveAccount(Account account) {
	        return accountDao.save(account);
	    }
}
