package com.bootcamp26.webflux.apirest.app.models.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bootcamp26.webflux.apirest.app.models.dao.AccountDao;
import com.bootcamp26.webflux.apirest.app.models.dao.PersonDao;
import com.bootcamp26.webflux.apirest.app.models.documents.Account;
import com.bootcamp26.webflux.apirest.app.models.documents.Person;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class AccountServiceImpl implements AccountService {

	   @Autowired
	    private AccountDao dao;

	    @Autowired
	    private PersonDao personDao;

	    @Override
	    public Flux<Account> findAll() {
	        return dao.findAll();
	    }

	    @Override
	    public Mono<Account> findById(String id) {
	        return dao.findById(id);
	    }

	    @Override
	    public Mono<Account> save(Account account) {
	        return dao.save(account);
	    }

	    @Override
	    public Mono<Void> delete(Account account) {
	        return dao.delete(account);
	    }

	    @Override
	    public Mono<Account> findByAccountNumber(String accountNumber) {
	        return dao.findByAccountNumber(accountNumber);
	    }

	    @Override
	    public Flux<Person> findAllPerson() {
	        return personDao.findAll();
	    }

	    @Override
	    public Mono<Person> findPersonById(String id) {
	        return personDao.findById(id);
	    }

	    @Override
	    public Mono<Person> savePerson(Person person) {
	        return personDao.save(person);
	    }

/*
	    @Override
	    public Mono<Person> findPersonByName(String name) {
	        return personDao.findBy(name);
	    }
*/
}
