package com.bootcamp26.webflux.apirest.app;

import com.bootcamp26.webflux.apirest.app.models.documents.Account;
import com.bootcamp26.webflux.apirest.app.models.documents.Movement;
import com.bootcamp26.webflux.apirest.app.models.documents.Person;
import com.bootcamp26.webflux.apirest.app.models.documents.PersonType;
import com.bootcamp26.webflux.apirest.app.models.services.AccountService;
import com.bootcamp26.webflux.apirest.app.models.services.MovementService;
import com.bootcamp26.webflux.apirest.app.models.services.PersonService;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.LinkedHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.http.MediaType;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.core.ParameterizedTypeReference;

@EnableEurekaClient
@SpringBootApplication
public class WebfluxApirestApplication implements CommandLineRunner {

	@Autowired
	private PersonService service;
	
	@Autowired
	private AccountService accountService;
	
	@Autowired
	private MovementService movementService;
	
	@Autowired
	private ReactiveMongoTemplate mongoTemplate;

	private static final Logger log = LoggerFactory.getLogger(WebfluxApirestApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(WebfluxApirestApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		mongoTemplate.dropCollection("movements").subscribe();
		mongoTemplate.dropCollection("accounts").subscribe();
		mongoTemplate.dropCollection("persons").subscribe();		
		mongoTemplate.dropCollection("personTypes").subscribe();

		//DocumentType dni = new DocumentType("Dni");
		//DocumentType ruc = new DocumentType("ruc");

		
		PersonType personaNatural = new PersonType("Natural");
		PersonType personaJuridica = new PersonType("Juridica");

		Person persona1 = new Person( "Dni", "41410345", "JUAN PEREZ PEREZ", personaNatural, "CALLE 28 DE JULIO 23", "624684684", "", 1 );
		Person persona2 = new Person( "Ruc", "20414103450", "REPRESENTACIONES ABC", personaJuridica, "AV. METROPOLITANA", "92857285", "", 1);
		Person persona3 = new Person( "Dni", "41410340", "CARLOS RAMIREZ SANDOVAL", personaNatural, "CALLE HUSARES DE JUNIN 345", "97655643", "", 1);
		
		
		Person persona4 = new Person( "Dni", "40000020", "PERSONA MONEDERO 1", personaNatural, "CALLE S/N", "940000020", "acepta20@gmail.com", 1);
		Person persona5 = new Person( "Dni", "40000021", "PERSONA MONEDERO 2", personaNatural, "CALLE S/N", "940000021", "acepta21@gmail.com", 1);
		Person persona6 = new Person( "Dni", "40000022", "PERSONA MONEDERO 3", personaNatural, "CALLE S/N", "940000022", "acepta22@gmail.com", 1);
		Person persona7 = new Person( "Dni", "40000023", "PERSONA MONEDERO 4", personaNatural, "CALLE S/N", "940000023", "acepta23@gmail.com", 1);
		
				
		Account account1 = new Account( "CUENTA AHORROS", persona1, "50045645654547", "1050045645654547", "2022-01-01", 1000.00, 1000.00, 1 );
		
		Movement movement1 = new Movement( 1000.00, "APERTURA CUENTA", account1, 1 );
		
		
		Flux.just(personaNatural, personaJuridica)
			.flatMap(service::savePersonType)
			.doOnNext(c ->{ log.info("Tipo de Persona creada: " + c.getDescription() + ", Id: " + c.getId()); })
			.thenMany(
				Flux.just(persona1, persona2, persona3, persona4, persona5, persona6, persona7)
					.flatMap(person -> { return service.save(person); })
					.doOnNext(p -> { log.info("Persona creada: " + p.getName() + ", Id: " + p.getId()); })
					.thenMany(
							Flux.just(account1)
								.flatMap(account -> { return accountService.save(account); })
								.doOnNext(a -> { log.info("Cuenta creada: " + a.getAccountNumber() + ", Id: " + a.getId()); })
								.thenMany(
										Flux.just(movement1)
										.flatMap(movement -> { return movementService.save(movement); })
										)
							)
					)
		.subscribe(account -> log.info("Insert: " + account.getId() + " " + account.getOperationType()));


		
		
		Person personh = service.findByDocumentNumber("41410345").block();
		Account accountx = new Account( "CUENTA PLAZO FIJO", personh, "10245645654546", "1010245645654547", "2022-01-01", 1000.00, 1000.00, 1 );
		
		Flux.just(accountx)
		.flatMap(accountService::save)
		.doOnNext(a -> { log.info("Cuenta tipo 2 creada: " + a.getAccountNumber() + ", Id: " + a.getId()); })
		.subscribe(account -> log.info("Insert: " + account.getId() + " " + account.getAccountNumber()));

		
		Person personh1 = service.findByDocumentNumber("40000020").block();
		Account accountx1 = new Account( "CUENTA MONEDERO MOVIL", personh1, "90045645654546", "1090045645654547", "2022-01-01", 1000.00, 1000.00, 1 );
		
		Flux.just(accountx1)
		.flatMap(accountService::save)
		.doOnNext(a -> { log.info("Cuenta tipo 2 creada: " + a.getAccountNumber() + ", Id: " + a.getId()); })
		.subscribe(account -> log.info("Insert: " + account.getId() + " " + account.getAccountNumber()));

		
		
		Person personh2 = service.findByDocumentNumber("40000021").block();
		Account accountx2 = new Account( "CUENTA AHORROS", personh2, "50045645654546", "1050045645654547", "2022-01-01", 1000.00, 1000.00, 1 );
		
		Flux.just(accountx2)
		.flatMap(accountService::save)
		.doOnNext(a -> { log.info("Cuenta tipo 2 creada: " + a.getAccountNumber() + ", Id: " + a.getId()); })
		.subscribe(account -> log.info("Insert: " + account.getId() + " " + account.getAccountNumber()));

		
		
		Person personh3 = service.findByDocumentNumber("40000022").block();
		Account accountx3 = new Account( "CUENTA MONEDERO MOVIL", personh3, "90045645654546", "1090045645654547", "2022-01-01", 1000.00, 1000.00, 1 );
		
		Flux.just(accountx3)
		.flatMap(accountService::save)
		.doOnNext(a -> { log.info("Cuenta tipo 2 creada: " + a.getAccountNumber() + ", Id: " + a.getId()); })
		.subscribe(account -> log.info("Insert: " + account.getId() + " " + account.getAccountNumber()));

		
		Person personh4 = service.findByDocumentNumber("40000023").block();
		Account accountx4 = new Account( "CUENTA AHORROS", personh4, "50045645654546", "1050045645654547", "2022-01-01", 1000.00, 1000.00, 1 );
		
		Flux.just(accountx4)
		.flatMap(accountService::save)
		.doOnNext(a -> { log.info("Cuenta tipo 2 creada: " + a.getAccountNumber() + ", Id: " + a.getId()); })
		.subscribe(account -> log.info("Insert: " + account.getId() + " " + account.getAccountNumber()));

		
		
		/*
		Flux<String> fluxpersonh = Flux.just(personh)
				.doOnNext(elemento -> System.out.println(elemento.toString()));
		
		fluxpersonh.subscribe();
		//System.out.println("prueba h: " + personh.getId());
*/
		
		/*
		Flux.just(personaNatural, personaJuridica)
				.flatMap(service::savePersonType)
				.doOnNext(c ->{
					log.info("Tipo de Persona creada: " + c.getDescription() + ", Id: " + c.getId());
				}).thenMany(
						Flux.just(new Person( "Dni", "41410345", "JUAN PEREZ PEREZ", personaNatural, "CALLE 28 DE JULIO 23", "624684684", "", 1 ),
									new	Person( "Ruc", "20414103450", "REPRESENTACIONES ABC", personaJuridica, "AV. METROPOLITANA", "92857285", "", 1),
									new	Person( "Dni", "41410340", "CARLOS RAMIREZ SANDOVAL", personaNatural, "CALLE HUSARES DE JUNIN 345", "97655643", "", 1)
								)
								.flatMap(person -> {
									return service.save(person);
								})
				)
				.subscribe(person -> log.info("Insert: " + person.getId() + " " + person.getName()));

		*/
		
		
		
		//Mono<Person> personx = service.findByDocumentNumber("41410345");
		//Account account1 = new Account( "CUENTA AHORROS", person1, "10245645654547", "1010245645654547", "2022-01-01", 1000.00, 1000.00, 1 );
		
	
		
		//Person person1 = service.findByDocumentNumber("41410345").block();
		//System.out.print("prueba:  " + person1.getName());
		
	/*	
		//log.info("Probando: " + person1.getName());
		Account account1 = new Account( "CUENTA AHORROS", person1, "10245645654547", "1010245645654547", "2022-01-01", 1000.00, 1000.00, 1 );
		
				
		
		//accountService.save(account1);
		
		Flux.just(account1)
		.flatMap(accountService::save)
		.doOnNext(c ->{
			log.info("Tipo de Persona creada: " + c.getAccountNumber() + ", Id: " + c.getId());
		})
		.subscribe();

*/
		
		//Mono<Person> person1 = service.findByDocumentNumber("41410345");
		
		//Account account1 = new Account( "CUENTA AHORROS", person1.subscribe(), "10245645654547", "1010245645654547", "2022-01-01", 1000, 1000, 1 );
		
		
		/*
		Flux.just(person1)
		.doOnNext(c ->{
			log.info("Tipo de Persona creada: ");
		}).thenMany(
				Flux.just(
						new Account( "CUENTA AHORROS", person1, "10245645654547", "1010245645654547", "2022-01-01", 1000,1000, 1 )
						)
						.flatMap(account -> {
							return accountService.save(account);
						})
		)
		.subscribe(person -> log.info("Insert: " + person.getId() + " " + person.getName()));
*/
		
		/*
		person1.thenMany(
				Flux.just(
						new Account( "CUENTA AHORROS", person1, "10245645654547", "1010245645654547", "2022-01-01", 1000,1000, 1 )
					)
					.flatMap(account -> {
						return service.save(account);
					})
				)
		.subscribe(account -> log.info("Insert: " + person.getId() + " " + person.getName()));
		*/
		
		/*
		Flux.just(person1)
		//.flatMap(accountService::savePersonType)
				.doOnNext(c ->{
					log.info("Tipo de Persona creada: " + c.getName() + ", Id: " + c.getId());
				}).thenMany(
						Flux.just(new Person( "Dni", "41410345", "JUAN PEREZ PEREZ", personaNatural, "CALLE 28 DE JULIO 23", "624684684", "", 1 ),
									new	Person( "Ruc", "20414103450", "REPRESENTACIONES ABC", personaJuridica, "AV. METROPOLITANA", "92857285", "", 1),
									new	Person( "Dni", "41410340", "CARLOS RAMIREZ SANDOVAL", personaNatural, "CALLE HUSARES DE JUNIN 345", "97655643", "", 1)
								)
								.flatMap(person -> {
									return service.save(person);
								})
				)
		.subscribe(person -> log.info("Insert: " + person.getId() + " " + person.getName()));
*/
		
		/*
		PersonType personaNatural = new PersonType("Persona Natural");
		PersonType personaJuridica = new PersonType("Persona Juridica");

		Flux.just(personaNatural, personaJuridica)
				.flatMap(service::savePersonType)
				.doOnNext(c ->{
					log.info("Tipo de Persona creada: " + c.getDescription() + ", Id: " + c.getId());
				}).thenMany(
						
						Person person = new Person( "Dni", "41410345", "JUAN PEREZ PEREZ", personaNatural, "CALLE 28 DE JULIO 23", "624684684", "", 1 );
						
						
						Flux.just(new Person( "Dni", "41410345", "JUAN PEREZ PEREZ", personaNatural, "CALLE 28 DE JULIO 23", "624684684", "", 1 ),
									new	Person( "Ruc", "20414103450", "REPRESENTACIONES ABC", personaJuridica, "AV. METROPOLITANA", "92857285", "", 1),
									new	Person( "Dni", "41410340", "CARLOS RAMIREZ SANDOVAL", personaNatural, "CALLE HUSARES DE JUNIN 345", "97655643", "", 1)
								)
								.flatMap(person -> {
									return service.save(person);
								})
								.doOnNext(ac ->{
									log.info("Persona creada: " + ac.getName() + ", Id: " + ac.getId());
								}).thenMany(Flux.just(new Person( "Dni", "41410345", "JUAN PEREZ PEREZ", personaNatural, "CALLE 28 DE JULIO 23", "624684684", "", 1 ),
									new	Person( "Ruc", "20414103450", "REPRESENTACIONES ABC", personaJuridica, "AV. METROPOLITANA", "92857285", "", 1),
									new	Person( "Dni", "41410340", "CARLOS RAMIREZ SANDOVAL", personaNatural, "CALLE HUSARES DE JUNIN 345", "97655643", "", 1)
								)
								.flatMap(person -> {
									return service.save(person);
								})
								)
				)
				.subscribe(person -> log.info("Insert: " + person.getId() + " " + person.getName()));
		*/
		
		
/*
		PersonType personaNatural = new PersonType("Persona Natural");
		PersonType personaJuridica = new PersonType("Persona Juridica");

		Flux.just(personaNatural, personaJuridica)
				.flatMap(service::savePersonType)
				.doOnNext(c ->{
					log.info("Tipo de Persona creada: " + c.getDescription() + ", Id: " + c.getId());
				}).thenMany(
						Flux.just(new Person( "Dni", "41410345", "JUAN PEREZ PEREZ", personaNatural, "CALLE 28 DE JULIO 23", "624684684", "", 1 ),
									new	Person( "Ruc", "20414103450", "REPRESENTACIONES ABC", personaJuridica, "AV. METROPOLITANA", "92857285", "", 1),
									new	Person( "Dni", "41410340", "CARLOS RAMIREZ SANDOVAL", personaNatural, "CALLE HUSARES DE JUNIN 345", "97655643", "", 1)
								)
								.flatMap(person -> {
									return service.save(person);
								})
				)
				.subscribe(person -> log.info("Insert: " + person.getId() + " " + person.getName()));

*/
		
		
	}
}
