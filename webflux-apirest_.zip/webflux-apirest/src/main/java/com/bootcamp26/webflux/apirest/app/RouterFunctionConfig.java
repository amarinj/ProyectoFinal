package com.bootcamp26.webflux.apirest.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.bootcamp26.webflux.apirest.app.handler.AccountHandler;
import com.bootcamp26.webflux.apirest.app.handler.MovementHandler;
import com.bootcamp26.webflux.apirest.app.handler.PersonHandler;

import static org.springframework.web.reactive.function.server.RouterFunctions.route;
import static org.springframework.web.reactive.function.server.RequestPredicates.*;

@Configuration
public class RouterFunctionConfig {

	@Bean
	public RouterFunction<ServerResponse> routes(PersonHandler handler){
		
		return route(GET("/api/v2/persons").or(GET("/api/bank/persons")), handler::listar)
				.andRoute(GET("/api/v2/persons/{id}").or(GET("/api/bank/persons/{id}")), handler::ver)
				.andRoute(GET("/api/v2/persons/doc/{documentNumber}").or(GET("/api/bank/persons/doc/{documentNumber}")), handler::buscarporNumeroDocumento)
				.andRoute(POST("/api/v2/persons").or(POST("/api/bank/persons")), handler::crear)
				.andRoute(PUT("/api/v2/persons/{id}").or(PUT("/api/bank/persons/{id}")), handler::editar)
				.andRoute(DELETE("/api/v2/persons/{id}").or(DELETE("/api/bank/persons/{id}")), handler::eliminar);
	}

	@Bean
	public RouterFunction<ServerResponse> routesAccount(AccountHandler handler){
		
		return route(GET("/api/v2/accounts").or(GET("/api/bank/accounts")), handler::listar)
				.andRoute(GET("/api/v2/accounts/{id}").or(GET("/api/bank/accounts/{id}")), handler::ver)
				.andRoute(POST("/api/v2/accounts").or(POST("/api/bank/accounts")), handler::crear)
				.andRoute(PUT("/api/v2/accounts/{id}").or(PUT("/api/bank/accounts/{id}")), handler::editar)
				.andRoute(DELETE("/api/v2/accounts/{id}").or(DELETE("/api/bank/accounts/{id}")), handler::eliminar);
	}

	
	@Bean
	public RouterFunction<ServerResponse> routesMovement(MovementHandler handler){
		
		return route(GET("/api/v2/movements").or(GET("/api/bank/movements")), handler::listar)
				.andRoute(GET("/api/v2/movements/{id}").or(GET("/api/bank/movements")), handler::ver)
				.andRoute(POST("/api/v2/movements").or(POST("/api/bank/movements")), handler::crear)
				.andRoute(PUT("/api/v2/movements/{id}").or(PUT("/api/bank/movements")), handler::editar)
				.andRoute(DELETE("/api/v2/movements/{id}").or(DELETE("/api/bank/movements")), handler::eliminar);
	}
}
