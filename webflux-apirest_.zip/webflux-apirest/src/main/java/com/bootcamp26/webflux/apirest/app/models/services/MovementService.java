package com.bootcamp26.webflux.apirest.app.models.services;

import com.bootcamp26.webflux.apirest.app.models.documents.Account;
import com.bootcamp26.webflux.apirest.app.models.documents.Movement;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface MovementService {
    public Flux<Movement> findAll();

    public Mono<Movement> findById(String id);

    public Mono<Movement> save(Movement movement);

    public Mono<Void> delete(Movement movement);

 
    public Flux<Account> findAllAccount();

    public Mono<Account> findAccountById(String id);

    public Mono<Account> saveAccount(Account account);

}
