package com.bootcamp26.webflux.apirest.app.handler;

import static org.springframework.web.reactive.function.BodyInserters.fromObject;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.bootcamp26.webflux.apirest.app.models.documents.Account;
import com.bootcamp26.webflux.apirest.app.models.services.AccountService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class AccountHandler {


	@Autowired
	private AccountService service;
		
	@Autowired
	private Validator validator;
	

	public Mono<ServerResponse> listar(ServerRequest request){
		return ServerResponse.ok()
				.contentType(MediaType.APPLICATION_JSON_UTF8)
				.body(service.findAll(), Account.class);
	}
	
	public Mono<ServerResponse> ver(ServerRequest request){
		
		String id = request.pathVariable("id");
		return service.findById(id).flatMap( p -> ServerResponse
				.ok()
				.contentType(MediaType.APPLICATION_JSON_UTF8)
				.body(fromObject(p)))
				.switchIfEmpty(ServerResponse.notFound().build());
	}
			
	public Mono<ServerResponse> crear(ServerRequest request){
		Mono<Account> account = request.bodyToMono(Account.class);
		
		return account.flatMap(p -> {
			
			Errors errors = new BeanPropertyBindingResult(p, Account.class.getName());
			validator.validate(p, errors);
			
			if(errors.hasErrors()) {
				return Flux.fromIterable(errors.getFieldErrors())
						.map(fieldError -> "El campo " + fieldError.getField() + " " + fieldError.getDefaultMessage())
						.collectList()
						.flatMap(list -> ServerResponse.badRequest().body(fromObject(list)));
			} else {
				//if(p.getCreateAt() ==null) {
				//	p.setCreateAt(new Date());
				//}
				return service.save(p).flatMap(pdb -> ServerResponse
						.created(URI.create("/api/v2/accounts/".concat(pdb.getId())))
						.contentType(MediaType.APPLICATION_JSON_UTF8)
						.body(fromObject(pdb)));
			}
			
		});
	}
	
	public Mono<ServerResponse> editar(ServerRequest request){
		Mono<Account> account = request.bodyToMono(Account.class);
		String id = request.pathVariable("id");
		
		Mono<Account> accountDb = service.findById(id);
		
		return accountDb.zipWith(account, (db, req) ->{			
			db.setAccountType(req.getAccountType());
			db.setPerson(req.getPerson());
			db.setAccountNumber(req.getAccountNumber());
			db.setCardNumber(req.getCardNumber());
			db.setDateExpires(req.getDateExpires());
			db.setLineAvailable(req.getLineAvailable());
			db.setBalanceAvailable(req.getBalanceAvailable());
			db.setState(req.getState());			
            
			return db;
		}).flatMap(p -> ServerResponse.created(URI.create("/api/v2/accounts/".concat(p.getId())))
				.contentType(MediaType.APPLICATION_JSON_UTF8)
				.body(service.save(p), Account.class))
		.switchIfEmpty(ServerResponse.notFound().build());
		
	}
	
	public Mono<ServerResponse> eliminar(ServerRequest request){
		String id = request.pathVariable("id");
		
		Mono<Account> accountDb = service.findById(id);
		
		return accountDb.flatMap(p-> service.delete(p).then(ServerResponse.noContent().build()))
				.switchIfEmpty(ServerResponse.notFound().build());
		
	}
	
}
